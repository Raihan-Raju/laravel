<script setup>
import "@/assets/admin-assets/vendor/fonts/boxicons.css"
import "@/assets/admin-assets/vendor/css/core.css"
import "@/assets/admin-assets/vendor/css/theme-default.css"
import "@/assets/admin-assets/css/demo.css"
import "@/assets/admin-assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css"
import "@/assets/admin-assets/vendor/libs/apex-charts/apex-charts.css"
import "@/assets/admin-assets/vendor/css/pages/page-auth.css"

// jss files
import "@/assets/admin-assets/vendor/js/helpers.js"
import "@/assets/admin-assets/js/config.js"
import "@/assets/admin-assets/vendor/libs/jquery/jquery.js"
import "@/assets/admin-assets/vendor/libs/popper/popper.js"
import "@/assets/admin-assets/vendor/js/bootstrap.js"
import "@/assets/admin-assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"
import "@/assets/admin-assets/vendor/js/menu.js"
import "@/assets/admin-assets/vendor/libs/apex-charts/apexcharts.js"
import "@/assets/admin-assets/js/main.js"
</script>

<template>
    <router-view/>
</template>