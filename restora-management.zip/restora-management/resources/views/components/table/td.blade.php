@props([

])

<td {{ $attributes->class(["align-middle text-center"]) }}>
    {{ $slot }}
</td>
