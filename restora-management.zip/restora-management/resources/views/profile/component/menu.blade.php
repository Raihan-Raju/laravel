 <nav class="nav nav-borders">
     <a class="nav-link " href="{{ route('profile.edit') }}">Profile</a>
     <a class="nav-link active " href="{{ route('profile.settings') }}">Settings</a>
     <a class="nav-link " href="{{ route('profile.store.settings') }}">Store</a>
 </nav>
